sudo sed -i '/home\/mini_cs/d' /etc/fstab
sleep 2
sudo mount -av